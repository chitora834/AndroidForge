package com.cryptoultravault.model

data class Coin(
    val id:String,val symbol:String,val name:String,val rank:Int,val price:Double,
    val change15m:Double=0.0,val change1h:Double=0.0,val change24h:Double=0.0,val change7d:Double=0.0,
    val marketCap:Double=0.0,val volume:Double=0.0,val circulating:Double=0.0,val totalSupply:Double=0.0,
    val maxSupply:Double=0.0,val ath:Double=0.0,val athDate:String="",val lastUpdated:String=""
)
data class Holding(val coinId:String,val symbol:String,var amount:Double,var avgPrice:Double)
data class AlertRule(val coinId:String,val symbol:String,val target:Double,val above:Boolean,val enabled:Boolean=true)
data class NewsItem(val title:String,val source:String,val url:String)
