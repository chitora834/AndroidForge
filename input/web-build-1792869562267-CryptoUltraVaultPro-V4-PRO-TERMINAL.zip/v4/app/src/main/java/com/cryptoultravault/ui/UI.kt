package com.cryptoultravault.ui
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView

object UI{
 const val BG=0xFF050911.toInt();const val CARD=0xFF0B1422.toInt();const val CARD2=0xFF101D2E.toInt();const val TEXT=0xFFF5F7FA.toInt();const val MUTED=0xFF8494AA.toInt();const val BLUE=0xFF55A7FF.toInt();const val CYAN=0xFF37D5FF.toInt();const val GREEN=0xFF28D7A5.toInt();const val RED=0xFFFF5576.toInt();const val GOLD=0xFFF6C85F.toInt();const val PURPLE=0xFF9C7BFF.toInt()
 fun bg(v:View,c:Int=CARD,r:Float=18f){v.background=GradientDrawable().apply{setColor(c);cornerRadius=r}}
 fun tv(ctx:Context,text:String,size:Float=14f,color:Int=TEXT)=TextView(ctx).apply{this.text=text;setTextSize(size);setTextColor(color);includeFontPadding=true}
 fun label(p:LinearLayout,t:String,size:Float=13f,c:Int=MUTED)=tv(p.context,t,size,c).also{p.addView(it,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=7})}
 fun card(p:LinearLayout,pad:Int=18)=MaterialCardView(p.context).apply{radius=22f;cardElevation=0f;setCardBackgroundColor(CARD);setContentPadding(pad,pad,pad,pad);p.addView(this,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=12})}
 fun inner(ctx:Context)=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL}
 fun button(p:ViewGroup,t:String,click:()->Unit)=MaterialButton(p.context).apply{this.text=t;textSize=12f;setOnClickListener{click()};p.addView(this,ViewGroup.LayoutParams(-1,52))}
 fun chip(p:LinearLayout,t:String,active:Boolean,click:()->Unit)=TextView(p.context).apply{ text=t;textSize=11f;gravity=17;setTextColor(if(active)TEXT else MUTED);setPadding(22,0,22,0);bg(this,if(active)BLUE else CARD2,30f);setOnClickListener{click()};p.addView(this,LinearLayout.LayoutParams(-2,42).apply{rightMargin=7})}
 fun stat(ctx:Context,title:String,value:String,sub:String,color:Int)=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL;setPadding(14,14,14,14);bg(this,CARD2,18f);addView(tv(ctx,title,10f,MUTED));addView(tv(ctx,value,20f,TEXT));addView(tv(ctx,sub,10f,color))}
}
