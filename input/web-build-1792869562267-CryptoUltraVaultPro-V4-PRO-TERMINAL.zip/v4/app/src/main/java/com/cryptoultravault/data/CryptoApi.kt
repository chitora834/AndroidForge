package com.cryptoultravault.data

import com.cryptoultravault.model.Coin
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class CryptoApi {
    private val base="https://api.coinpaprika.com/v1"
    private fun get(path:String):String{
        val c=URL(base+path).openConnection() as HttpURLConnection
        c.connectTimeout=15000;c.readTimeout=15000;c.requestMethod="GET"
        c.setRequestProperty("Accept","application/json")
        val code=c.responseCode
        val stream=if(code in 200..299)c.inputStream else c.errorStream
        val body=stream?.bufferedReader()?.use{it.readText()}?:""
        c.disconnect()
        if(code !in 200..299) throw RuntimeException("HTTP $code")
        return body
    }
    fun markets(limit:Int=100):List<Coin>{
        val a=JSONArray(get("/tickers?quotes=USD&limit=$limit"));val out=mutableListOf<Coin>()
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i);val q=o.optJSONObject("quotes")?.optJSONObject("USD")?:JSONObject()
            out+=Coin(o.optString("id"),o.optString("symbol"),o.optString("name"),o.optInt("rank",0),q.optDouble("price",0.0),
                q.optDouble("percent_change_15m",0.0),q.optDouble("percent_change_1h",0.0),q.optDouble("percent_change_24h",0.0),q.optDouble("percent_change_7d",0.0),
                q.optDouble("market_cap",0.0),q.optDouble("volume_24h",0.0),o.optDouble("circulating_supply",0.0),o.optDouble("total_supply",0.0),o.optDouble("max_supply",0.0),
                q.optDouble("ath_price",0.0),q.optString("ath_date"),o.optString("last_updated"))
        }
        return out
    }
    fun global():GlobalStats{
        val o=JSONObject(get("/global"));return GlobalStats(o.optDouble("market_cap_usd",0.0),o.optDouble("volume_24h_usd",0.0),o.optDouble("bitcoin_dominance_percentage",0.0),o.optDouble("market_cap_ath_value",0.0))
    }
    fun coin(id:String):Coin{
        val o=JSONObject(get("/tickers/$id?quotes=USD"));val q=o.optJSONObject("quotes")?.optJSONObject("USD")?:JSONObject()
        return Coin(o.optString("id"),o.optString("symbol"),o.optString("name"),o.optInt("rank",0),q.optDouble("price",0.0),q.optDouble("percent_change_15m",0.0),q.optDouble("percent_change_1h",0.0),q.optDouble("percent_change_24h",0.0),q.optDouble("percent_change_7d",0.0),q.optDouble("market_cap",0.0),q.optDouble("volume_24h",0.0),o.optDouble("circulating_supply",0.0),o.optDouble("total_supply",0.0),o.optDouble("max_supply",0.0),q.optDouble("ath_price",0.0),q.optString("ath_date"),o.optString("last_updated"))
    }
    fun history(id:String,days:Int=30):List<Double>{
        val start=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).apply{timeZone=java.util.TimeZone.getTimeZone("UTC")}.format(java.util.Date(System.currentTimeMillis()-days*86400000L))
        val a=JSONArray(get("/tickers/$id/historical?start=$start&interval=1d&quote=USD&limit=$days"));val r=mutableListOf<Double>()
        for(i in 0 until a.length())r+=a.getJSONObject(i).optDouble("price",0.0)
        return r
    }
    fun search(q:String):List<Coin>{
        val a=JSONArray(get("/search/?q="+URLEncoder.encode(q,"UTF-8")));val r=mutableListOf<Coin>()
        for(i in 0 until minOf(a.length(),20)){val o=a.getJSONObject(i);r+=Coin(o.optString("id"),o.optString("symbol"),o.optString("name"),o.optInt("rank",0),0.0)}
        return r
    }
}
data class GlobalStats(val marketCap:Double,val volume:Double,val btcDominance:Double,val ath:Double)
