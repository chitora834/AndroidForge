package com.cryptoultravault.ui
import android.content.Context
import android.graphics.*
import android.view.View
class ChartView(c:Context):View(c){
 private val paint=Paint(Paint.ANTI_ALIAS_FLAG);private var vals=doubleArrayOf();
 fun setValues(v:List<Double>){vals=v.toDoubleArray();invalidate()}
 override fun onDraw(c:Canvas){super.onDraw(c);if(vals.size<2)return;val min=vals.minOrNull()?:0.0;val max=vals.maxOrNull()?:1.0;val range=(max-min).coerceAtLeast(1e-12);paint.style=Paint.Style.STROKE;paint.strokeWidth=5f;paint.color=UI.BLUE;val p=Path();for(i in vals.indices){val x=i.toFloat()*width.toFloat()/(vals.size-1).toFloat();val y=height.toFloat()-( ((vals[i]-min)/range).toFloat()*height*.78f+height*.1f);if(i==0)p.moveTo(x,y)else p.lineTo(x,y)};c.drawPath(p,paint);paint.style=Paint.Style.FILL;paint.color=0x332F9BFF;val fill=Path(p);fill.lineTo(width.toFloat(),height.toFloat());fill.lineTo(0f,height.toFloat());fill.close();c.drawPath(fill,paint)}
}
