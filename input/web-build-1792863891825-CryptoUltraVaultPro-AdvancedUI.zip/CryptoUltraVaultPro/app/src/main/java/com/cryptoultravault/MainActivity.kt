package com.cryptoultravault
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
class MainActivity:AppCompatActivity(){
 private val bg=Color.rgb(7,17,31); private val card=Color.rgb(14,28,46); private val white=Color.rgb(244,247,251); private val muted=Color.rgb(142,163,186); private val green=Color.rgb(49,214,154); private val red=Color.rgb(255,102,122); private val blue=Color.rgb(77,141,255)
 private fun dp(x:Int)= (x*resources.displayMetrics.density).toInt()
 private fun text(s:String,z:Float,c:Int=white)=TextView(this).apply{text=s;textSize=z;setTextColor(c);setPadding(dp(12),dp(7),dp(12),dp(7))}
 private fun section(s:String)=text(s,15f,white).apply{setPadding(dp(4),dp(18),dp(4),dp(6))}
 override fun onCreate(b:Bundle?){super.onCreate(b); val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg)}
  val head=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(10),dp(8),dp(2))}; val brand=text("CryptoUltraVaultPro",20f);brand.setTypeface(null,1);head.addView(brand,LinearLayout.LayoutParams(0,dp(52),1f));head.addView(Button(this).apply{text="🔔"},LinearLayout.LayoutParams(dp(58),dp(52)));root.addView(head)
  val scroll=ScrollView(this); val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,dp(12),dp(80))};body.addView(text("Your crypto command center",14f,muted))
  val grid=GridLayout(this).apply{columnCount=2}; fun tile(a:String,b:String,c:String,col:Int):LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(8),dp(12),dp(8));setBackgroundColor(card);addView(text(a,11f,muted));addView(text(b,22f,col));addView(text(c,11f,muted))}
  listOf(tile("PORTFOLIO","$0.00","Track holdings",green),tile("MARKET","24,812","Assets",blue),tile("BTC","$67,420","+2.41%",green),tile("ETH","$2,485","-0.63%",red)).forEach{grid.addView(it,GridLayout.LayoutParams().apply{width=0;height=dp(112);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(dp(5),dp(5),dp(5),dp(5))})};body.addView(grid)
  body.addView(section("MARKET RADAR"));body.addView(text("🔥 Trending   •   🆕 New listings   •   ⚡ Gainers   •   📉 Losers",13f,muted));body.addView(section("WATCHLIST"));body.addView(text("★ BTC     $67,420     +2.41%",15f,green));body.addView(text("★ ETH     $2,485       -0.63%",15f,red));body.addView(text("☆ SOL     $158.20      +4.18%",15f,green));body.addView(section("TOOLS"))
  val tools=LinearLayout(this);tools.orientation=LinearLayout.HORIZONTAL;listOf("Converter","Alerts","News","GameFi","Airdrops","Risk").forEach{x->tools.addView(Button(this).apply{text=x;setOnClickListener{Toast.makeText(this@MainActivity,"$x module",Toast.LENGTH_SHORT).show()}},LinearLayout.LayoutParams(0,dp(52),1f))};body.addView(tools);body.addView(section("ANALYSIS"));body.addView(text("Market momentum  •  Volume  •  Market cap  •  Fear & Greed  •  Risk signals",13f,muted));body.addView(text("Real UI foundation — live data is not fabricated.",12f,muted));scroll.addView(body);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
  val nav=LinearLayout(this).apply{setBackgroundColor(card)};listOf("⌂ Home","◈ Markets","★ Watchlist","▣ Portfolio","☰ More").forEach{x->nav.addView(text(x,11f).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,dp(62),1f))};root.addView(nav);setContentView(root)
 }
}
