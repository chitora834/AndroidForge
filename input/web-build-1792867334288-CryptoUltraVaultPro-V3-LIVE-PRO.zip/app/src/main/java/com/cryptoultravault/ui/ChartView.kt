package com.cryptoultravault.ui
import android.content.Context
import android.graphics.*
import android.view.View
class ChartView(c:Context):View(c){
 private val paint=Paint(Paint.ANTI_ALIAS_FLAG); private var vals=doubleArrayOf()
 fun setValues(v:List<Double>){vals=v.toDoubleArray();invalidate()}
 override fun onDraw(x:Canvas){super.onDraw(x); if(vals.size<2)return
  val min=vals.minOrNull()?:0.0; val max=vals.maxOrNull()?:1.0; val range=(max-min).coerceAtLeast(1e-9)
  paint.style=Paint.Style.STROKE;paint.strokeWidth=4f;paint.color=UI.BLUE
  val p=Path(); vals.indices.forEach{i->val px=i*width.toFloat()/(vals.size-1);val py=height-( ((vals[i]-min)/range)*height*0.82+height*0.08).toFloat();if(i==0)p.moveTo(px,py)else p.lineTo(px,py)};x.drawPath(p,paint)
  paint.style=Paint.Style.FILL;paint.color=0x335EA8FF;val fill=Path(p);fill.lineTo(width.toFloat(),height.toFloat());fill.lineTo(0f,height.toFloat());fill.close();x.drawPath(fill,paint)
 }
}
