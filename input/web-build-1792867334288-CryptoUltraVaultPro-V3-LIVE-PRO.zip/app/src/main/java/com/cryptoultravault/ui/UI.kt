package com.cryptoultravault.ui
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.android.material.button.MaterialButton
object UI{
 const val BG=0xFF060B14.toInt();const val CARD=0xFF0D1624.toInt();const val CARD2=0xFF111E30.toInt();const val TEXT=0xFFF4F7FC.toInt();const val MUTED=0xFF8292A8.toInt();const val BLUE=0xFF58A6FF.toInt();const val GREEN=0xFF22D3A2.toInt();const val RED=0xFFFF5D78.toInt();const val GOLD=0xFFF5C451.toInt()
 fun bg(v:View,c:Int=CARD,r:Float=18f){v.background=GradientDrawable().apply{setColor(c);cornerRadius=r}}
 fun tv(ctx:android.content.Context,text:String,size:Float=15f,color:Int=TEXT)=TextView(ctx).apply{this.text=text;setTextSize(size);setTextColor(color)}
 fun label(parent:LinearLayout,text:String,size:Float=14f,color:Int=MUTED)=TextView(parent.context).apply{this.text=text;setTextSize(size);setTextColor(color);parent.addView(this,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=7})}
 fun card(parent:LinearLayout)=LinearLayout(parent.context).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18);bg(this);parent.addView(this,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,12)})}
 fun button(parent:ViewGroup,text:String,onClick:()->Unit)=MaterialButton(parent.context).apply{this.text=text;setTextColor(TEXT);setOnClickListener{onClick()};parent.addView(this,ViewGroup.LayoutParams(-1,52))}
 fun pill(ctx:android.content.Context,text:String,color:Int)=TextView(ctx).apply{this.text=text;setTextColor(color);textSize=11f;gravity=17;setPadding(12,5,12,5);bg(this,0x201FFFFFF.toInt(),20f)}
}
