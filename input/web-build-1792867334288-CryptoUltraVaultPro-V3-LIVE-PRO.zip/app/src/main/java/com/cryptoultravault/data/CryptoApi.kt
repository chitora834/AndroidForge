package com.cryptoultravault.data

import com.cryptoultravault.model.Coin
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class CryptoApi {
    private fun get(url:String): String {
        val c=URL(url).openConnection() as HttpURLConnection
        c.connectTimeout=12000; c.readTimeout=12000; c.requestMethod="GET"
        c.setRequestProperty("Accept","application/json")
        return try { c.inputStream.bufferedReader().use{it.readText()} } finally { c.disconnect() }
    }
    fun markets(perPage:Int=100,page:Int=1):List<Coin>{
        val text=get("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=$perPage&page=$page&sparkline=false&price_change_percentage=1h,24h,7d")
        val a=JSONArray(text); val out=mutableListOf<Coin>()
        for(i in 0 until a.length()) { val o=a.getJSONObject(i); out+=Coin(
            o.getString("id"),o.optString("symbol").uppercase(),o.optString("name"),o.optDouble("current_price",0.0),
            o.optDouble("price_change_percentage_24h",0.0),o.optDouble("market_cap",0.0),o.optDouble("total_volume",0.0),
            o.optDouble("price_change_percentage_1h_in_currency",0.0),o.optDouble("price_change_percentage_7d_in_currency",0.0),
            o.optString("image")) }
        return out
    }
    fun chart(id:String,days:Int=1):List<Double>{
        val a=JSONObject(get("https://api.coingecko.com/api/v3/coins/$id/market_chart?vs_currency=usd&days=$days"))
            .getJSONArray("prices"); val out=ArrayList<Double>(a.length())
        for(i in 0 until a.length()) out+=a.getJSONArray(i).getDouble(1)
        return out
    }
    fun global():GlobalStats {
        val o=JSONObject(get("https://api.coingecko.com/api/v3/global")).getJSONObject("data")
        return GlobalStats(o.optDouble("total_market_cap",0.0),o.optDouble("total_volume",0.0),o.optDouble("market_cap_change_percentage_24h_usd",0.0),o.optJSONObject("market_cap_percentage")?.optDouble("btc",0.0)?:0.0)
    }
}
data class GlobalStats(val marketCap:Double,val volume:Double,val change:Double,val btcDominance:Double)
