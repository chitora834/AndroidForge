# Changelog

## 0.1.0 Ultimate foundation
- Replaced placeholder/web-style structure with a real native Kotlin Android project.
- Added API-driven market screen and filters.
- Added dashboard, portfolio, radar and tools navigation.
- Added reusable UI components and formatting utilities.
- Added GitHub Actions build pipeline.
