# Product Specification

## Dashboard
Portfolio value, 24h P/L, market cap, volume, BTC dominance, watchlist movers, top gainers, top losers, radar score, alerts and curated discovery cards.

## Markets
Search by name, symbol or contract identifier. Sort by price, market cap, volume, 1h, 24h and 7d. Filter by market-cap bands, category, chain and volatility. Infinite pagination keeps the interface responsive while allowing a very large asset universe.

## Asset detail
Price, multi-timeframe chart, market cap, FDV, volume, supply, ATH/ATL, percentage changes, rank, categories, supported markets, chain/address metadata where the provider supplies it, watchlist toggle, alert creation and risk report.

## Portfolio
Manual holdings, average entry price, quantity, realized/unrealized P/L, allocation, cost basis, notes and optional local-only privacy mode. No wallet connection is required.

## Radar
Ranks discovery candidates using momentum, volume, size and risk. It must clearly distinguish algorithmic signals from investment advice.

## GameFi/P2E
Catalog opportunities by chain, game status, entry cost, token, reward type, withdrawal method, activity date and risk. Never promise earnings.

## Airdrops
Track project, task, chain, deadline, eligibility, status and official source. Unknown links receive warnings.

## Alerts
Price above/below, percentage move, volume spike and newly detected opportunity. Background notifications are opt-in.

## Converter
Crypto-to-crypto and crypto-to-fiat. Fiat list begins with USD and PKR and can expand.

## Risk
Rule-based warnings for micro caps, extreme volatility, thin volume, supply concentration, unverified data and suspicious links. Provider-supported security data can be added later.
