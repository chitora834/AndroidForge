# CryptoUltraVaultPro Ultimate

A native Android crypto research and portfolio companion. This project is intentionally **not a WebView app** and does not request wallet private keys.

## Included now
- Native Android Kotlin UI with dashboard, markets, portfolio, radar and tools sections
- Live CoinGecko market data integration
- Pagination-ready market loading
- Search across loaded coins
- Gainers / losers / micro-cap / low-cap / high-volume filters
- Coin detail panel with price, market cap, volume, supply, ATH/ATL and changes
- Local portfolio entry flow (no wallet connection)
- Token Radar with opportunity/risk cards
- Professional dark UI foundation and reusable UI kit
- GitHub Actions debug APK build and artifact upload

## Data coverage
The market list is API-driven rather than hard-coded. The app can load hundreds of assets per page and can be extended to additional providers/chains. No app can honestly guarantee every token ever created because new/unindexed tokens appear continuously.

## Safety
This is a research/tracking application. It does not custody funds, store seed phrases, or execute trades. Micro-cap and new-token information is inherently risky; verify contracts and sources before interacting with any token or site.

## Build
Push the repository to GitHub and open **Actions → Build CryptoUltraVaultPro Ultimate → Run workflow**. The debug APK is uploaded as a workflow artifact.
