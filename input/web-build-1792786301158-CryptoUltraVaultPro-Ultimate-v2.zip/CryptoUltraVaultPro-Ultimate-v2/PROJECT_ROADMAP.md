# Ultimate Roadmap

## Phase 1 — Foundation
- Native Android shell
- Live market API
- Search/filter/sort
- Portfolio/watchlist data model
- Alerts architecture

## Phase 2 — Market intelligence
- Multiple data providers with fallback
- Chain-aware token discovery
- New listings feed
- Micro-cap scoring
- Liquidity/volume anomaly detection
- Contract/address explorer links
- Detailed interactive charts

## Phase 3 — Pro hubs
- GameFi database
- P2E opportunity tracker
- Airdrop/task tracker
- News aggregation
- Risk scoring and scam-warning rules
- Notification engine

## Phase 4 — Personalization
- Local encrypted preferences
- Watchlist sync option (opt-in)
- Portfolio P/L, cost basis and allocation
- Custom alerts
- USD/PKR and multi-fiat conversion

## Phase 5 — Performance
- Offline cache
- Background refresh
- Paging/infinite scroll
- API rate-limit handling
- Error states and retry queue
