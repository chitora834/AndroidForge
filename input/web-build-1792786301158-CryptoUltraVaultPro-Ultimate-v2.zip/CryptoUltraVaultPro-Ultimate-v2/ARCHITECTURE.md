# CryptoUltraVaultPro Ultimate Architecture

The app is deliberately separated into model, data, domain, services, widgets and UI layers so future providers can be added without rewriting screens.

## Market data strategy
1. Provider adapter fetches paginated assets.
2. Repository normalizes symbols, price, volume, supply and changes.
3. Local cache can serve the last successful snapshot.
4. Screens operate on normalized Coin models.
5. Provider rate limits are handled with retry/backoff in the production networking layer.

## Token coverage strategy
The app must never ship a hard-coded list pretending to be "all coins". It requests pages from providers and supports filters over the returned universe. A future multi-provider layer can merge CoinGecko, DexScreener, GeckoTerminal and chain-specific indexers where their public terms permit it.

## Micro-cap strategy
Micro-cap is a discovery category, not a quality claim. Ranking should combine liquidity, volume, price momentum, market cap, holder concentration where available, contract verification, age and risk signals.

## Security model
No seed phrase, private key or wallet-signing secret is requested by the base app. External token pages should open in a browser and display strong warnings. Any future wallet integration must be an explicit opt-in module.

## Performance
Use paging, background refresh, cached JSON and lightweight list rows. Do not load every token icon at once. Detail charts should request history only when a user opens an asset.
