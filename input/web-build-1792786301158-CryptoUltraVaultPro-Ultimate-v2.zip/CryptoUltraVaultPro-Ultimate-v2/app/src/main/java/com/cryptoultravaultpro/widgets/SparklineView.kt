package com.cryptoultravaultpro.widgets
import android.graphics.*
import android.view.View
class SparklineView:View {private val paint=Paint(1);private var points=emptyList<Float>();constructor(c:android.content.Context):super(c){paint.style=Paint.Style.STROKE;paint.strokeWidth=5f;paint.color=Color.rgb(108,124,255)}
 fun setData(v:List<Float>){points=v;invalidate()}
 override fun onDraw(c:Canvas){super.onDraw(c);if(points.size<2)return;val min=points.minOrNull()?:0f;val max=points.maxOrNull()?:1f;val path=Path();points.forEachIndexed{i,x->val xx=i*width.toFloat()/(points.size-1);val yy=height-(if(max==min).5f else (x-min)/(max-min))*height*.8f-height*.1f;if(i==0)path.moveTo(xx,yy)else path.lineTo(xx,yy)};c.drawPath(path,paint)} }
