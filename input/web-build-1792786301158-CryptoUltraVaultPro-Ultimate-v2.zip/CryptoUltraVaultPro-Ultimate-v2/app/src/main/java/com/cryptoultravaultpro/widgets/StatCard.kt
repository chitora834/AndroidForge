package com.cryptoultravaultpro.widgets
import android.content.Context
import android.graphics.Color
import android.widget.LinearLayout
import android.widget.TextView
class StatCard(c:Context,title:String,value:String,sub:String=""):LinearLayout(c){init{orientation=VERTICAL;setPadding(18,15,18,15);setBackgroundColor(Color.rgb(16,21,34));val a=TextView(c);a.text=title;a.setTextColor(Color.rgb(140,150,170));a.textSize=12f;addView(a);val b=TextView(c);b.text=value;b.setTextColor(Color.WHITE);b.textSize=21f;addView(b);if(sub.isNotEmpty()){val d=TextView(c);d.text=sub;d.setTextColor(Color.rgb(140,150,170));d.textSize=11f;addView(d)}}}
