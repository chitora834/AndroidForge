package com.cryptoultravaultpro.ui
import android.graphics.Color
import android.view.*
import android.widget.*
import android.content.Context
import com.cryptoultravaultpro.model.Coin
import com.cryptoultravaultpro.util.Formatters

class MarketAdapter(private val ctx:Context, private var data:List<Coin>, private val click:(Coin)->Unit):BaseAdapter(){
 fun update(d:List<Coin>){data=d;notifyDataSetChanged()}
 override fun getCount()=data.size; override fun getItem(p:Int)=data[p]; override fun getItemId(p:Int)=p
 override fun getView(p:Int,cv:View?,parent:ViewGroup):View { val c=data[p]; val row=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL;setPadding(14,12,14,12);setOnClickListener{click(c)}}
  val left=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL};left.addView(UiKit.text(ctx,"${c.rank}. ${c.name}",15f,true));left.addView(UiKit.muted(ctx,c.symbol));
  row.addView(left,LinearLayout.LayoutParams(0,-2,1f)); val right=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.RIGHT};right.addView(UiKit.text(ctx,Formatters.money(c.price),14f,true));val ch=UiKit.text(ctx,Formatters.pct(c.change24h),12f);ch.setTextColor(Color.parseColor(if(c.change24h>=0)"#28D17C" else "#FF5D73"));right.addView(ch);row.addView(right);return row }
}
