package com.cryptoultravaultpro.model

data class Coin(
    val id:String,val symbol:String,val name:String,val image:String?,val price:Double,val marketCap:Double,val volume:Double,
    val change1h:Double,val change24h:Double,val change7d:Double,val rank:Int,val circulating:Double,val total:Double,val ath:Double,val atl:Double
)

data class Holding(val coinId:String,val symbol:String,val name:String,val quantity:Double,val averagePrice:Double)
data class PriceAlert(val coinId:String,val symbol:String,val target:Double,val above:Boolean)
