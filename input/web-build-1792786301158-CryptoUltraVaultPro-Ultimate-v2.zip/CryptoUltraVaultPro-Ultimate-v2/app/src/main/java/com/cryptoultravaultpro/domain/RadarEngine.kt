package com.cryptoultravaultpro.domain
import com.cryptoultravaultpro.model.Coin

data class RadarScore(val coin:Coin,val score:Double,val labels:List<String>)
object RadarEngine {
 fun rank(coins:List<Coin>):List<RadarScore>{return coins.map{c->var s=0.0;val labels=mutableListOf<String>();if(c.change24h>0){s+=20;labels.add("Momentum")};if(c.volume>c.marketCap*.05){s+=20;labels.add("Volume")};if(c.marketCap<1e9){s+=20;labels.add("Small cap")};if(c.change7d>0){s+=15;labels.add("7D strength")};if(c.rank in 1..100){s+=10;labels.add("Established")};s-=RiskEngine.analyze(c).score*.15;RadarScore(c,s,labels)}.sortedByDescending{it.score}}
}
