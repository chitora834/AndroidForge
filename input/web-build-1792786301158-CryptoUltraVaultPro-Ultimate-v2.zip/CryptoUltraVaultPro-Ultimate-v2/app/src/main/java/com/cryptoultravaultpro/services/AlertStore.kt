package com.cryptoultravaultpro.services
import android.content.Context
import com.cryptoultravaultpro.model.PriceAlert
import org.json.JSONArray
import org.json.JSONObject
class AlertStore(c:Context){private val p=c.getSharedPreferences("alerts",0)
 fun all():List<PriceAlert>{val a=JSONArray(p.getString("items","[]"));return (0 until a.length()).map{val o=a.getJSONObject(it);PriceAlert(o.getString("id"),o.getString("symbol"),o.getDouble("target"),o.getBoolean("above"))}}
 fun add(x:PriceAlert){val a=JSONArray();all().forEach{a.put(JSONObject().apply{put("id",it.coinId);put("symbol",it.symbol);put("target",it.target);put("above",it.above)})};a.put(JSONObject().apply{put("id",x.coinId);put("symbol",x.symbol);put("target",x.target);put("above",x.above)});p.edit().putString("items",a.toString()).apply()}
}
