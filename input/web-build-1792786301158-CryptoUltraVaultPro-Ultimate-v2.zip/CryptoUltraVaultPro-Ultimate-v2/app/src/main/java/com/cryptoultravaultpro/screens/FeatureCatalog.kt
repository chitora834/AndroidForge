package com.cryptoultravaultpro.screens
object FeatureCatalog {
 val marketFilters=listOf("All assets","Top 10","Top 100","Gainers","Losers","Trending","New listings","Micro cap","Low cap","High volume","High volatility","Stablecoins","DeFi","GameFi","Meme","Layer 1","Layer 2","AI","RWA","DEX")
 val chains=listOf("All chains","Ethereum","BNB Chain","Solana","Polygon","Arbitrum","Base","Avalanche","TRON","Optimism","Sui","Aptos","TON","Cardano","XRP Ledger","Bitcoin")
 val tools=listOf("Converter","Portfolio","Watchlist","Price alerts","Market screener","Token radar","Risk scanner","News","GameFi hub","Airdrop tracker","Gas tracker","Dominance","Fear & greed","DCA calculator","Profit calculator","FDV calculator","APY calculator")
}
