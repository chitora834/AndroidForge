package com.cryptoultravaultpro.util
import android.content.Context
class Prefs(c:Context){ private val p=c.getSharedPreferences("vault",Context.MODE_PRIVATE)
    fun getString(k:String,d:String="")=p.getString(k,d)?:d
    fun putString(k:String,v:String)=p.edit().putString(k,v).apply()
    fun getBoolean(k:String,d:Boolean=false)=p.getBoolean(k,d)
    fun putBoolean(k:String,v:Boolean)=p.edit().putBoolean(k,v).apply()
}
