package com.cryptoultravaultpro.data

import com.cryptoultravaultpro.model.Coin
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class CoinGeckoClient {
    private fun get(path:String):String {
        val c=URL("https://api.coingecko.com/api/v3/$path").openConnection() as HttpURLConnection
        c.connectTimeout=15000;c.readTimeout=20000;c.requestMethod="GET";c.setRequestProperty("Accept","application/json")
        return c.inputStream.bufferedReader().use{it.readText()}
    }
    fun markets(page:Int, perPage:Int=100):List<Coin> {
        val q="coins/markets?vs_currency=usd&order=market_cap_desc&per_page=$perPage&page=$page&sparkline=false&price_change_percentage=1h,24h,7d"
        val a=JSONArray(get(q)); val out=ArrayList<Coin>()
        for(i in 0 until a.length()) { val o=a.getJSONObject(i)
            out.add(Coin(o.optString("id"),o.optString("symbol").uppercase(Locale.US),o.optString("name"),o.optString("image",null),o.optDouble("current_price"),o.optDouble("market_cap"),o.optDouble("total_volume"),o.optDouble("price_change_percentage_1h_in_currency"),o.optDouble("price_change_percentage_24h"),o.optDouble("price_change_percentage_7d_in_currency"),o.optInt("market_cap_rank"),o.optDouble("circulating_supply"),o.optDouble("total_supply"),o.optDouble("ath"),o.optDouble("atl")))
        }; return out
    }
    fun search(query:String):List<Pair<String,String>> {
        val a=JSONArray(get("search?query="+java.net.URLEncoder.encode(query,"UTF-8"))); return emptyList()
    }
}
