package com.cryptoultravaultpro.util
import java.text.NumberFormat
import java.util.Locale
object Formatters {
    fun money(v:Double):String = when { v>=1e12 -> String.format(Locale.US,"$%.2fT",v/1e12); v>=1e9 -> String.format(Locale.US,"$%.2fB",v/1e9); v>=1e6 -> String.format(Locale.US,"$%.2fM",v/1e6); v>=1e3 -> String.format(Locale.US,"$%.2fK",v/1e3); v>=1 -> String.format(Locale.US,"$%,.2f",v); v>=0.01 -> String.format(Locale.US,"$%.4f",v); else -> String.format(Locale.US,"$%.8f",v) }
    fun compact(v:Double):String = when { v>=1e12 -> String.format(Locale.US,"%.2fT",v/1e12); v>=1e9 -> String.format(Locale.US,"%.2fB",v/1e9); v>=1e6 -> String.format(Locale.US,"%.2fM",v/1e6); v>=1e3 -> String.format(Locale.US,"%.2fK",v/1e3); else -> String.format(Locale.US,"%.2f",v) }
    fun pct(v:Double):String = String.format(Locale.US,"%+.2f%%",v)
}
