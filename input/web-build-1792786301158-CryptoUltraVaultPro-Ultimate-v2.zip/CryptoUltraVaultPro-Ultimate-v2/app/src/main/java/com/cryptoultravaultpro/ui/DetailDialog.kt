package com.cryptoultravaultpro.ui
import android.app.AlertDialog
import android.content.Context
import com.cryptoultravaultpro.model.Coin
import com.cryptoultravaultpro.util.Formatters
class DetailDialog(private val ctx:Context, private val c:Coin){
 fun show(){ val l=UiKit.panel(ctx);l.addView(UiKit.text(ctx,"${c.name} (${c.symbol})",22f,true));l.addView(UiKit.muted(ctx,"Rank #${c.rank}"));l.addView(UiKit.text(ctx,"Price  ${Formatters.money(c.price)}",17f));l.addView(UiKit.text(ctx,"24h  ${Formatters.pct(c.change24h)}"));l.addView(UiKit.text(ctx,"7d   ${Formatters.pct(c.change7d)}"));l.addView(UiKit.text(ctx,"Market Cap  $${Formatters.compact(c.marketCap)}"));l.addView(UiKit.text(ctx,"Volume      $${Formatters.compact(c.volume)}"));l.addView(UiKit.text(ctx,"Circulating  ${Formatters.compact(c.circulating)}"));l.addView(UiKit.text(ctx,"ATH ${Formatters.money(c.ath)}   ATL ${Formatters.money(c.atl)}"));AlertDialog.Builder(ctx).setView(l).setPositiveButton("Close",null).setNeutralButton("Add to Watchlist",null).show() }
}
