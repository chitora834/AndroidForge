package com.cryptoultravaultpro.domain
import com.cryptoultravaultpro.model.Coin

data class RiskReport(val score:Int,val level:String,val reasons:List<String>)
object RiskEngine {
 fun analyze(c:Coin):RiskReport { var score=0;val reasons=mutableListOf<String>();
  if(c.marketCap<50_000_000){score+=30;reasons.add("Micro-cap: high volatility and liquidity risk")}
  else if(c.marketCap<1_000_000_000){score+=15;reasons.add("Low-cap asset")}
  if(c.volume<=0 || c.volume/c.marketCap<0.01){score+=25;reasons.add("Low volume relative to market cap")}
  if(c.change24h>30 || c.change24h< -30){score+=20;reasons.add("Extreme 24h price movement")}
  if(c.total>0 && c.circulating/c.total<0.2){score+=15;reasons.add("Large portion of supply may remain")}
  val level=when{score>=70->"VERY HIGH";score>=45->"HIGH";score>=20->"MEDIUM";else->"LOW"};return RiskReport(score.coerceAtMost(100),level,reasons)
 }
}
