package com.cryptoultravaultpro.model

enum class MarketFilter { ALL, GAINERS, LOSERS, MICRO_CAP, LOW_CAP, HIGH_VOLUME, NEWEST }
data class NewsItem(val title:String,val source:String,val url:String,val time:String)
data class Opportunity(val title:String,val type:String,val chain:String,val risk:String,val note:String)
