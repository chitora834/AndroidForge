package com.cryptoultravaultpro.services
import android.content.Context
import com.cryptoultravaultpro.model.Holding
import org.json.JSONArray
import org.json.JSONObject
class PortfolioStore(c:Context){private val p=c.getSharedPreferences("portfolio",0)
 fun all():List<Holding>{val a=JSONArray(p.getString("items","[]"));return (0 until a.length()).map{val o=a.getJSONObject(it);Holding(o.getString("id"),o.getString("symbol"),o.getString("name"),o.getDouble("qty"),o.getDouble("avg"))}}
 fun add(h:Holding){val a=JSONArray();all().forEach{a.put(JSONObject().apply{put("id",it.coinId);put("symbol",it.symbol);put("name",it.name);put("qty",it.quantity);put("avg",it.averagePrice)})};a.put(JSONObject().apply{put("id",h.coinId);put("symbol",h.symbol);put("name",h.name);put("qty",h.quantity);put("avg",h.averagePrice)});p.edit().putString("items",a.toString()).apply()}
 fun clear(){p.edit().remove("items").apply()}
}
