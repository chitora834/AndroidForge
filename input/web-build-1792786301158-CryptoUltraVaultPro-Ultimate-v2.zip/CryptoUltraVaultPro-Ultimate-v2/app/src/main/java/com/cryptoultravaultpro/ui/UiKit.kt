package com.cryptoultravaultpro.ui
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.*
import android.content.Context
import com.cryptoultravaultpro.R

object UiKit {
 fun bg(v:android.view.View){v.setBackgroundColor(Color.parseColor("#070A12"))}
 fun panel(ctx:Context):LinearLayout { val l=LinearLayout(ctx);l.orientation=LinearLayout.VERTICAL;l.setPadding(18,16,18,16);l.background=GradientDrawable().apply{cornerRadius=24f;setColor(Color.parseColor("#101522"))};return l }
 fun text(ctx:Context,s:String,size:Float=14f,bold:Boolean=false):TextView=TextView(ctx).apply{text=s;textSize=size;setTextColor(Color.parseColor("#F5F7FB"));if(bold) setTypeface(typeface,1);setPadding(0,4,0,4)}
 fun muted(ctx:Context,s:String,size:Float=12f)=text(ctx,s,size).apply{setTextColor(Color.parseColor("#8C96AA"))}
 fun row(ctx:Context):LinearLayout=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
 fun button(ctx:Context,s:String):Button=Button(ctx).apply{text=s;textSize=12f;setTextColor(Color.WHITE);setBackgroundColor(Color.parseColor("#6C7CFF"))}
}
