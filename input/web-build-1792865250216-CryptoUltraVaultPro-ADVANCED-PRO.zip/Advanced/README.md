# CryptoUltraVaultPro — Advanced Terminal

A free-first Android crypto market/portfolio dashboard designed for phone-first cloud builds.

## Included
- Live CoinGecko market feed for up to 100 markets
- Search, gainers, losers and top-market-cap scanner
- Coin detail pages with price, market cap, volume and rule-based market snapshot
- Local portfolio with cost basis and P/L analytics
- Local watchlist
- Local price-alert storage
- Converter
- News / Airdrop / GameFi / Risk / Security module placeholders with transparent status
- Advanced dark terminal-style navigation
- Java 17 / Kotlin JVM 17 compatibility

## Important
The app does not fabricate live news, airdrops, GameFi or security results. Those modules are integration points until a verified source is connected.
No paid API key is required for the current core market feed, although public API limits can change.
