package com.cryptoultravault.ui
import android.content.Context
import android.graphics.*
import android.view.View
class ChartView(c:Context):View(c){private val paint=Paint(1);private val vals=doubleArrayOf(34,39,37,45,42,49,46,54,51,62,58,66,63,71,69,77,74,82);override fun onDraw(x:Canvas){super.onDraw(x);paint.color=Color.rgb(94,168,255);paint.style=Paint.Style.STROKE;paint.strokeWidth=5f;val p=Path();for(i in vals.indices){val px=i*width/(vals.size-1f);val py=height-(vals[i]/90f*height);if(i==0)p.moveTo(px,py)else p.lineTo(px,py)};x.drawPath(p,paint);paint.style=Paint.Style.FILL;paint.color=Color.argb(45,94,168,255);val fill=Path(p);fill.lineTo(width.toFloat(),height.toFloat());fill.lineTo(0f,height.toFloat());fill.close();x.drawPath(fill,paint)}}
