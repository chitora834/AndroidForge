package com.cryptoultravault.model

data class Coin(val id:String,val symbol:String,val name:String,val price:Double,val change:Double,val marketCap:Double=0.0,val volume:Double=0.0)
data class Holding(val coinId:String,val symbol:String,var amount:Double,var avgPrice:Double)
data class AlertRule(val coinId:String,val symbol:String,val target:Double,val above:Boolean,val enabled:Boolean=true)
data class NewsItem(val title:String,val source:String,val url:String)
