package com.cryptoultravault.data

import android.content.Context

class WatchStore(context: Context) {
    private val prefs = context.getSharedPreferences("watch", Context.MODE_PRIVATE)

    fun all(): Set<String> {
        return prefs.getStringSet("ids", emptySet()) ?: emptySet()
    }

    fun toggle(id: String) {
        val updated = all().toMutableSet()
        if (!updated.add(id)) updated.remove(id)
        prefs.edit().putStringSet("ids", updated).apply()
    }
}
