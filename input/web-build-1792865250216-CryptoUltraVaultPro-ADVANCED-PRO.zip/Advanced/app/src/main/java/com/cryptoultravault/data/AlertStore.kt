package com.cryptoultravault.data
import android.content.Context
import com.cryptoultravault.model.AlertRule
import org.json.JSONArray
import org.json.JSONObject
class AlertStore(c:Context){private val p=c.getSharedPreferences("alerts",0)
 fun all():MutableList<AlertRule>{val a=JSONArray(p.getString("a","[]"));val r=mutableListOf<AlertRule>();for(i in 0 until a.length()){val o=a.getJSONObject(i);r+=AlertRule(o.getString("id"),o.getString("s"),o.getDouble("t"),o.getBoolean("b"),o.getBoolean("e"))};return r}
 fun add(x:AlertRule){val a=all();a.removeAll{it.coinId==x.coinId};a+=x;save(a)}
 fun save(xs:List<AlertRule>){val a=JSONArray();xs.forEach{x->val o=JSONObject();o.put("id",x.coinId);o.put("s",x.symbol);o.put("t",x.target);o.put("b",x.above);o.put("e",x.enabled);a.put(o)};p.edit().putString("a",a.toString()).apply()}
}
