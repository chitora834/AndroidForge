package com.cryptoultravault

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.cryptoultravault.data.*
import com.cryptoultravault.model.*
import com.cryptoultravault.ui.*
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var content: FrameLayout
    private val api = CryptoApi()
    private val exec = Executors.newSingleThreadExecutor()
    private lateinit var portfolio: PortfolioStore
    private lateinit var watch: WatchStore
    private lateinit var alerts: AlertStore
    private var coins = mutableListOf<Coin>()
    private var lastUpdated = "Not updated"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        portfolio = PortfolioStore(this); watch = WatchStore(this); alerts = AlertStore(this)
        buildShell(); showHome(); refreshMarkets()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(UI.BG) }
        val header = LinearLayout(this).apply { setPadding(18, 16, 18, 10); gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply { text = "CUV  PRO"; textSize = 21f; setTypeface(null, 1); setTextColor(UI.TEXT) }
        header.addView(brand, LinearLayout.LayoutParams(0, 62, 1f))
        val refresh = TextView(this).apply { text = "↻"; textSize = 30f; setTextColor(UI.BLUE); gravity = Gravity.CENTER; setOnClickListener { refreshMarkets() } }
        header.addView(refresh, LinearLayout.LayoutParams(54, 62))
        root.addView(header)
        content = FrameLayout(this); root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { setPadding(6, 7, 6, 7); setBackgroundColor(UI.CARD) }
        listOf("⌂\nHome", "◉\nMarkets", "▣\nPortfolio", "⚑\nAlerts", "⋯\nMore").forEach { label ->
            val v = TextView(this).apply { text = label; gravity = Gravity.CENTER; textSize = 11f; setTextColor(UI.MUTED); setOnClickListener {
                when (label.substringAfterLast("\n")) { "Home" -> showHome(); "Markets" -> showMarkets(); "Portfolio" -> showPortfolio(); "Alerts" -> showAlerts(); else -> showMore() }
            }}
            nav.addView(v, LinearLayout.LayoutParams(0, 64, 1f))
        }
        root.addView(nav); setContentView(root)
    }

    private fun base(): LinearLayout {
        content.removeAllViews(); val scroll = ScrollView(this).apply { setPadding(14, 4, 14, 18) }
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; scroll.addView(l); content.addView(scroll); return l
    }
    private fun money(v: Double): String = if (v >= 1000) String.format(Locale.US, "%,.0f", v) else if (v >= 1) String.format(Locale.US, "%.2f", v) else String.format(Locale.US, "%.6f", v)
    private fun pct(v: Double) = String.format(Locale.US, "%+.2f%%", v)

    private fun showHome() {
        val l = base(); UI.label(l, "PRO MARKET TERMINAL", 12f, UI.BLUE)
        val hero = UI.card(l); UI.label(hero, "TOTAL PORTFOLIO", 12f)
        val total = portfolio.all().sumOf { h -> h.amount * (coins.firstOrNull { it.id == h.coinId }?.price ?: h.avgPrice) }
        UI.label(hero, "$${money(total)}", 30f, UI.TEXT)
        UI.label(hero, if (portfolio.all().isEmpty()) "Add holdings to unlock P/L analytics" else "Local portfolio • no wallet connection", 12f)
        val metrics = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        metric(metrics, "Assets", portfolio.all().size.toString()); metric(metrics, "Watch", watch.all().size.toString()); metric(metrics, "Alerts", alerts.all().size.toString()); hero.addView(metrics)
        val chart = ChartView(this); hero.addView(chart, LinearLayout.LayoutParams(-1, 210).apply { topMargin = 10 })
        val market = UI.card(l); UI.label(market, "MARKET PULSE", 12f, UI.BLUE)
        if (coins.isEmpty()) UI.label(market, "Connecting to live market feed…", 15f, UI.TEXT)
        coins.take(6).forEach { coin -> compactCoin(market, coin) }
        UI.label(market, "Updated: $lastUpdated", 11f)
        val quick = UI.card(l); UI.label(quick, "QUICK ACCESS", 12f, UI.BLUE)
        listOf("Market Scanner" to { showMarkets() }, "Portfolio Analytics" to { showPortfolio() }, "Converter & Tools" to { showMore() }, "Airdrops / GameFi / Risk" to { showMore() }).forEach { (name, action) -> UI.button(quick, name, action) }
    }

    private fun metric(parent: LinearLayout, name: String, value: String) { val x = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(4, 12, 4, 4) }; UI.label(x, value, 18f, UI.TEXT); UI.label(x, name, 10f); parent.addView(x, LinearLayout.LayoutParams(0, -2, 1f)) }
    private fun compactCoin(parent: LinearLayout, c: Coin) { val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, 12, 0, 12) }; val t = UI.tv(this, "${c.symbol}  ${c.name}\n$${money(c.price)}   ${pct(c.change)}", 15f); row.addView(t, LinearLayout.LayoutParams(0, -2, 1f)); val star = UI.tv(this, if (watch.all().contains(c.id)) "★" else "☆", 25f, UI.BLUE); star.setOnClickListener { watch.toggle(c.id); star.text = if (watch.all().contains(c.id)) "★" else "☆" }; row.addView(star, LinearLayout.LayoutParams(48, 70)); row.setOnClickListener { showCoin(c) }; parent.addView(row) }

    private fun refreshMarkets() { exec.execute { try { val data = api.markets(100); coins = data.toMutableList(); lastUpdated = java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date()); runOnUiThread { showHome() } } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Market feed unavailable", Toast.LENGTH_SHORT).show() } } } }

    private fun showMarkets() {
        val l = base(); val top = LinearLayout(this); val search = EditText(this).apply { hint = "Search 100+ markets"; setTextColor(UI.TEXT); setHintTextColor(UI.MUTED); setSingleLine(); setPadding(14,0,14,0) }; UI.bg(search, UI.CARD, 16f); top.addView(search, LinearLayout.LayoutParams(0, 58, 1f)); l.addView(top)
        val filters = LinearLayout(this); listOf("All", "Gainers", "Losers", "Top Cap").forEach { f -> val b = TextView(this).apply { text = f; gravity = Gravity.CENTER; setTextColor(UI.TEXT); setPadding(12,0,12,0); setOnClickListener { renderMarkets(l, search.text.toString(), f) } }; filters.addView(b, LinearLayout.LayoutParams(0,48,1f)) }; l.addView(filters)
        UI.label(l, "MARKET SCANNER • ${coins.size} loaded", 12f, UI.BLUE); renderMarkets(l, "", "All")
        search.addTextChangedListener(object : TextWatcher { override fun beforeTextChanged(s: CharSequence?, a:Int,b:Int,c:Int){}; override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){renderMarkets(l,s.toString(),"All")}; override fun afterTextChanged(e:Editable?){} })
    }
    private fun renderMarkets(l: LinearLayout, q: String, filter: String) {
        while (l.childCount > 2) l.removeViewAt(2)
        var xs = coins.filter { q.isBlank() || it.name.contains(q,true) || it.symbol.contains(q,true) }
        xs = when(filter) { "Gainers" -> xs.sortedByDescending { it.change }; "Losers" -> xs.sortedBy { it.change }; "Top Cap" -> xs.sortedByDescending { it.marketCap }; else -> xs }
        xs.take(100).forEach { compactCoin(l, it) }
    }

    private fun showCoin(c: Coin) {
        val l = base(); UI.label(l, "MARKET DETAIL", 12f, UI.BLUE); val h = UI.card(l); UI.label(h, c.name, 13f); UI.label(h, c.symbol, 13f, UI.MUTED); UI.label(h, "$${money(c.price)}", 32f, UI.TEXT); UI.label(h, "24h  ${pct(c.change)}", 16f, if(c.change >= 0) UI.GREEN else UI.RED); UI.label(h, "Market cap  $${money(c.marketCap)}\nVolume  $${money(c.volume)}", 13f)
        h.addView(ChartView(this), LinearLayout.LayoutParams(-1, 280).apply { topMargin = 10 }); UI.button(h, if (watch.all().contains(c.id)) "Remove from Watchlist" else "Add to Watchlist") { watch.toggle(c.id); showCoin(c) }; UI.button(h, "Add to Portfolio") { addHolding(c) }; UI.button(h, "Create Price Alert") { createAlert(c) }
        val insight = UI.card(l); UI.label(insight, "SMART MARKET SNAPSHOT", 12f, UI.BLUE); UI.label(insight, riskText(c), 15f, UI.TEXT)
    }
    private fun riskText(c: Coin): String { val vol = c.volume / (c.marketCap.coerceAtLeast(1.0)); return when { c.change > 10 -> "Momentum: HIGH • Risk: elevated due to sharp 24h move."; c.change < -10 -> "Momentum: bearish • Risk: elevated drawdown pressure."; vol > .25 -> "Liquidity: strong relative volume • Monitor volatility."; else -> "Momentum: neutral • No automatic buy/sell recommendation." } }

    private fun addHolding(c: Coin) { val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; val a=EditText(this).apply{hint="Amount";inputType=2};val p=EditText(this).apply{hint="Average buy price USD";inputType=2};box.addView(a);box.addView(p);AlertDialog.Builder(this).setTitle("Add ${c.symbol}").setView(box).setPositiveButton("Save"){_,_->portfolio.add(c.id,c.symbol,a.text.toString().toDoubleOrNull()?:0.0,p.text.toString().toDoubleOrNull()?:c.price);showPortfolio()}.setNegativeButton("Cancel",null).show() }
    private fun createAlert(c: Coin) { val e=EditText(this).apply{hint="Target price USD";inputType=2};AlertDialog.Builder(this).setTitle("Alert ${c.symbol}").setView(e).setPositiveButton("Save"){_,_->alerts.add(AlertRule(c.id,c.symbol,e.text.toString().toDoubleOrNull()?:c.price,true));showAlerts()}.setNegativeButton("Cancel",null).show() }

    private fun showPortfolio() { val l=base();UI.label(l,"PORTFOLIO ANALYTICS",12f,UI.BLUE);val card=UI.card(l);var value=0.0;var cost=0.0;portfolio.all().forEach{h->val c=coins.firstOrNull{it.id==h.coinId};value+=h.amount*(c?.price?:h.avgPrice);cost+=h.amount*h.avgPrice};UI.label(card,"$${money(value)}",32f,UI.TEXT);val pl=value-cost;UI.label(card,"P/L  ${if(pl>=0) "+" else ""}$${money(pl)}   (${if(cost>0)String.format(Locale.US,"%+.2f%%",pl/cost*100) else "0.00%"})",15f,if(pl>=0)UI.GREEN else UI.RED);UI.label(card,"Cost basis  $${money(cost)}",12f);portfolio.all().forEach{h->UI.label(card,"${h.symbol}   ${h.amount}\nAvg $${money(h.avgPrice)}",16f,UI.TEXT)};if(portfolio.all().isEmpty())UI.label(card,"No holdings. Add coins from Markets.",15f);UI.button(card,"Clear Portfolio"){portfolio.save(emptyList());showPortfolio()} }
    private fun showAlerts() { val l=base();UI.label(l,"ALERT CENTER",12f,UI.BLUE);val c=UI.card(l);if(alerts.all().isEmpty())UI.label(c,"No alerts yet.",15f);alerts.all().forEach{a->val row=LinearLayout(this);UI.label(row,"${a.symbol}  ${if(a.above) "above" else "below"}  $${money(a.target)}",15f,UI.TEXT);c.addView(row)}}

    private fun showMore() { val l=base();UI.label(l,"COMMAND CENTER",12f,UI.BLUE);val tools=UI.card(l);UI.label(tools,"CONVERTER",13f,UI.BLUE);val amount=EditText(this).apply{hint="USD amount";inputType=2};val price=EditText(this).apply{hint="Coin price USD";inputType=2};val out=UI.tv(this,"Result",18f);tools.addView(amount);tools.addView(price);tools.addView(out);UI.button(tools,"Convert"){val a=amount.text.toString().toDoubleOrNull()?:0.0;val p=price.text.toString().toDoubleOrNull()?:0.0;out.text=if(p>0)String.format(Locale.US,"%.8f coins",a/p) else "Enter valid price"}
        val modules=UI.card(l);UI.label(modules,"PRO MODULES",13f,UI.BLUE);listOf("📰 News Hub" to "Feed-ready news module", "🪂 Airdrop Radar" to "Source-based opportunities", "🎮 GameFi Radar" to "Free vs investment-required", "🛡 Risk Engine" to "Transparent rule-based warnings", "🔐 Security" to "Verified-provider integration point", "⚙ Settings" to "API / refresh / privacy controls").forEach{(a,b)->UI.label(modules,"$a\n$b",16f,UI.TEXT)}
        UI.label(l,"Free-first design: no paid service is required for the current core app.",12f,UI.MUTED)
    }
    override fun onDestroy(){exec.shutdown();super.onDestroy()}
}
