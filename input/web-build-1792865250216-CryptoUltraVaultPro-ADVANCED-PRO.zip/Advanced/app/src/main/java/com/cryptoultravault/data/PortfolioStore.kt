package com.cryptoultravault.data

import android.content.Context
import com.cryptoultravault.model.Holding
import org.json.JSONArray
import org.json.JSONObject

class PortfolioStore(context:Context){
 private val p=context.getSharedPreferences("portfolio",0)
 fun all():MutableList<Holding>{
  val out=mutableListOf<Holding>(); val a=JSONArray(p.getString("items","[]"))
  for(i in 0 until a.length()){val o=a.getJSONObject(i);out+=Holding(o.getString("id"),o.getString("symbol"),o.getDouble("amount"),o.getDouble("avg"))};return out
 }
 fun save(items:List<Holding>){val a=JSONArray();items.forEach{val o=JSONObject();o.put("id",it.coinId);o.put("symbol",it.symbol);o.put("amount",it.amount);o.put("avg",it.avgPrice);a.put(o)};p.edit().putString("items",a.toString()).apply()}
 fun add(id:String,symbol:String,amount:Double,avg:Double){val x=all();x.removeAll{it.coinId==id};x+=Holding(id,symbol,amount,avg);save(x)}
 fun remove(id:String){save(all().filterNot{it.coinId==id})}
}
