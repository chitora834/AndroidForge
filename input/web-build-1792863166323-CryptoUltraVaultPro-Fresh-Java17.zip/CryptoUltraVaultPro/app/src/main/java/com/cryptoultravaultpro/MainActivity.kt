package com.cryptoultravaultpro
import android.os.Bundle
import android.graphics.Color
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
class MainActivity: AppCompatActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b); val s=ScrollView(this); val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,30,20,30);setBackgroundColor(Color.rgb(11,17,24))};
 fun t(x:String,z:Float,c:Int,b:Boolean=false)=TextView(this).apply{text=x;textSize=z;setTextColor(c);setPadding(0,10,0,10);if(b)setTypeface(typeface,1)}
 r.addView(t("CryptoUltraVaultPro",28f,Color.WHITE,true));r.addView(t("PRO CRYPTO COMMAND CENTER",12f,Color.rgb(22,199,132),true));
 listOf("Portfolio — manual holdings without wallet connection","Market Radar — coins, tokens, gainers, losers, volume","Charts & Analysis — price, market cap, volume, trends","Converter — crypto ↔ crypto ↔ USD ↔ PKR","Alerts — price and market notifications","News & Airdrops — opportunities and risk warnings","GameFi / P2E — free and investment-required games","Security — token and wallet risk reminders").forEach{r.addView(t(it,17f,Color.WHITE,true))};
 r.addView(t("Starter build. Live APIs, persistent data, notifications and GameFi/news feeds are intentionally not claimed as connected yet.",12f,Color.LTGRAY));s.addView(r);setContentView(s)} }
