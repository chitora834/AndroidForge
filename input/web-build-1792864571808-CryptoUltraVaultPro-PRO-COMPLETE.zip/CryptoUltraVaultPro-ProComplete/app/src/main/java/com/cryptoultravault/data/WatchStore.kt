package com.cryptoultravault.data
import android.content.Context
class WatchStore(c:Context){private val p=c.getSharedPreferences("watch",0);fun all():Set<String>=p.getStringSet("ids",emptySet())?:emptySet();fun toggle(id:String){val s=all().toMutableSet();if(!s.add(id))s.remove(id);p.edit().putStringSet("ids",s).apply()}}
