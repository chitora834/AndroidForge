package com.cryptoultravault.data

import com.cryptoultravault.model.Coin
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray

class CryptoApi {
 fun markets():List<Coin>{
  val u=URL("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=50&page=1&sparkline=false")
  val c=u.openConnection() as HttpURLConnection;c.connectTimeout=9000;c.readTimeout=9000;c.requestMethod="GET"
  val text=c.inputStream.bufferedReader().use{it.readText()};val a=JSONArray(text);val out=mutableListOf<Coin>()
  for(i in 0 until a.length()){val o=a.getJSONObject(i);out+=Coin(o.getString("id"),o.getString("symbol").uppercase(),o.getString("name"),o.optDouble("current_price",0.0),o.optDouble("price_change_percentage_24h",0.0),o.optDouble("market_cap",0.0),o.optDouble("total_volume",0.0))};return out
 }
}
