# CryptoUltraVaultPro — Pro Complete Foundation

A real native Android project designed for phone-first cloud builds.

Included: live CoinGecko market loading when network/API is available, 50-market search, local portfolio, watchlist, local price alerts, converter, chart UI, news/airdrop/GameFi/risk hubs, and a professional dark dashboard.

No paid API is required by the project. Live feed availability depends on the public API's current limits/terms. The app does not pretend offline/demo values are live.

Build target: Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Java/Kotlin JVM 17, compileSdk 35, minSdk 26.
