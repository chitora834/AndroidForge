package com.cryptoultravault.ui

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

object UI{
 const val BG=0xFF08111F.toInt();const val CARD=0xFF101C2D.toInt();const val TEXT=0xFFF5F8FF.toInt();const val MUTED=0xFF8EA1BA.toInt();const val BLUE=0xFF5EA8FF.toInt();const val GREEN=0xFF28D7A1.toInt();const val RED=0xFFFF637D.toInt()
 fun bg(v:View,c:Int=CARD,r:Float=18f){v.background=GradientDrawable().apply{setColor(c);cornerRadius=r};return}
 fun tv(ctx:android.content.Context,text:String,size:Float=15f,color:Int=TEXT):TextView=TextView(ctx).apply{this.text=text;setTextSize(size);setTextColor(color)}
 fun label(parent:LinearLayout,text:String,size:Float=14f,color:Int=MUTED):TextView=TextView(parent.context).apply{this.text=text;setTextSize(size);setTextColor(color);parent.addView(this,LinearLayout.LayoutParams(-1,-2))}
 fun card(parent:LinearLayout):LinearLayout=LinearLayout(parent.context).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18);bg(this);parent.addView(this,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,14)})}
 fun button(parent:ViewGroup,text:String,onClick:()->Unit)=MaterialButton(parent.context).apply{this.text=text;setTextColor(TEXT);setOnClickListener{onClick()};parent.addView(this,ViewGroup.LayoutParams(-1,56))}
}
