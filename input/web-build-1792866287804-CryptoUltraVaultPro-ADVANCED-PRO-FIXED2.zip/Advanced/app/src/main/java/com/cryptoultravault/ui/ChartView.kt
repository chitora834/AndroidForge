package com.cryptoultravault.ui
import android.content.Context
import android.graphics.*
import android.view.View
class ChartView(c:Context):View(c){private val paint=Paint(1);private val vals=doubleArrayOf(34.0,39.0,37.0,45.0,42.0,49.0,46.0,54.0,51.0,62.0,58.0,66.0,63.0,71.0,69.0,77.0,74.0,82.0);override fun onDraw(x:Canvas){super.onDraw(x);paint.color=Color.rgb(94,168,255);paint.style=Paint.Style.STROKE;paint.strokeWidth=5f;val p=Path();for(i in vals.indices){val px=i*width/(vals.size-1f);val py=height-(vals[i]/90.0*height);if(i==0)p.moveTo(px,py.toFloat())else p.lineTo(px,py.toFloat())};x.drawPath(p,paint);paint.style=Paint.Style.FILL;paint.color=Color.argb(45,94,168,255);val fill=Path(p);fill.lineTo(width.toFloat(),height.toFloat());fill.lineTo(0f,height.toFloat());fill.close();x.drawPath(fill,paint)}}
